#include <Arduino.h>
// Copyright (c) Sandeep Mistry. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

/*
 * Serial Port over BLE
 * Create UART service compatible with Nordic's *nRF Toolbox* and Adafruit's *Bluefruit LE* iOS/Android apps.
 *
 * BLESerial class implements same protocols as Arduino's built-in Serial class and can be used as it's wireless
 * replacement. Data transfers are routed through a BLE service with TX and RX characteristics. To make the
 * service discoverable all UUIDs are NUS (Nordic UART Service) compatible.
 *
 * Please note that TX and RX characteristics use Notify and WriteWithoutResponse, so there's no guarantee
 * that the data will make it to the other end. However, under normal circumstances and reasonable signal
 * strengths everything works well.
 */

// Import libraries (BLEPeripheral depends on SPI)
#include <SPI.h>
#include <BLEPeripheral.h>
#include "BLESerial.h"
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// define pins (varies per shield/board)
#define BLE_REQ 0
#define BLE_RDY 0
#define BLE_RST 0

#define MTU	20

// create ble serial instance, see pinouts above
BLESerial BLESerial(BLE_REQ, BLE_RDY, BLE_RST);
Adafruit_MPU6050 mpu;
bool connection_status = false;

void connected(BLECentral &central)
{
	connection_status = true;
	Serial.println("Connected to ble");
}

void disconnected(BLECentral &central)
{
	connection_status = false;
	Serial.println("Disconnected from ble");
}

void SetupGpio()
{
	pinMode(LED_BUILTIN, OUTPUT);
	// pinMode(PIN_BUTTON1, INPUT_PULLUP);
}

void Test_GPIO()
{
	for (int i = 0; i < 3; i++)
	{
		digitalWrite(LED_BUILTIN, HIGH);
		delay(100);
		digitalWrite(LED_BUILTIN, LOW);
		delay(100);
	}
}

void blink_led()
{
	digitalWrite(LED_BUILTIN, HIGH);
	delay(50);
	digitalWrite(LED_BUILTIN, LOW);
	delay(50);
}

void SensorInit(mpu6050_accel_range_t Acceration_Range, mpu6050_bandwidth_t Bandwidth);

// forward received from Serial to BLESerial and vice versa
void forward()
{
	if (BLESerial && Serial)
	{
		int byte;
		while ((byte = BLESerial.read()) > 0)
			Serial.write((char)byte);
		while ((byte = Serial.read()) > 0)
			BLESerial.write((char)byte);
	}
}

void setup()
{
	SetupGpio();
	Test_GPIO();
	// custom services and characteristics can be added as well
	BLESerial.setLocalName("UART");

	Serial.begin(115200);
	BLESerial.setEventHandler(BLEConnected, connected);
	BLESerial.setEventHandler(BLEDisconnected, disconnected);
	BLESerial.begin();

	Serial.println("timestamp,accX,accY,accZ,gyroX,gyroY,gyroZ");
	SensorInit(MPU6050_RANGE_16_G, MPU6050_BAND_5_HZ);
}

void loop()
{
	sensors_event_t a, g, temp;
	char buf[200] = {0};
	char temp_buf[21] = {0};

	if (connection_status)
		blink_led();

	BLESerial.poll();

	mpu.getEvent(&a, &g, &temp);
/*
	sprintf(buf, "[%d]: %g cel accel [x][y][z] %f %f %f gyro [r][p][y] %f %f %f\r\n",
		millis(), temp.temperature, a.acceleration.x, a.acceleration.y,
		a.acceleration.z, g.gyro.roll, g.gyro.pitch,
		g.gyro.heading);
*/
	sprintf(buf, "%ld,%f,%f,%f,%f,%f,%f\r\n",
		millis(),a.acceleration.x, a.acceleration.y,
		a.acceleration.z, g.gyro.roll, g.gyro.pitch,
		g.gyro.heading);
	Serial.println();
	Serial.print(String(__FILE__) + String(" : ") + String(__func__) + String(": "));
	Serial.println(buf);

	for (int i = 0; i < strlen(buf); i += MTU) {
		strncpy(temp_buf, &buf[i], MTU);
		BLESerial.write(temp_buf);
		BLESerial.flush();
	}

	delay(10);
}

void SensorInit(mpu6050_accel_range_t Acceration_Range,
	mpu6050_bandwidth_t Bandwidth)
{
	if (!mpu.begin())
	{
		Serial.println("Failed to find MPU6050 chip");
		while (1)
		{
			delay(10);
		}
	}
#if defined(DEBUG_REQUIRED)
	Serial.println("MPU6050 Found!");
#endif

	// mpu.setAccelerometerRange(MPU6050_RANGE_16_G);
	mpu.setAccelerometerRange(Acceration_Range);
	Serial.print("Accelerometer range set to: ");
	switch (mpu.getAccelerometerRange())
	{
	case MPU6050_RANGE_2_G:
		Serial.println("+-2G");
		break;
	case MPU6050_RANGE_4_G:
		Serial.println("+-4G");
		break;
	case MPU6050_RANGE_8_G:
		Serial.println("+-8G");
		break;
	case MPU6050_RANGE_16_G:
		Serial.println("+-16G");
		break;
	}

	// mpu.setFilterBandwidth(MPU6050_BAND_5_HZ);
	mpu.setFilterBandwidth(Bandwidth);
	Serial.print("Filter bandwidth set to: ");
	switch (mpu.getFilterBandwidth())
	{
	case MPU6050_BAND_260_HZ:
		Serial.println("260 Hz");
		break;
	case MPU6050_BAND_184_HZ:
		Serial.println("184 Hz");
		break;
	case MPU6050_BAND_94_HZ:
		Serial.println("94 Hz");
		break;
	case MPU6050_BAND_44_HZ:
		Serial.println("44 Hz");
		break;
	case MPU6050_BAND_21_HZ:
		Serial.println("21 Hz");
		break;
	case MPU6050_BAND_10_HZ:
		Serial.println("10 Hz");
		break;
	case MPU6050_BAND_5_HZ:
		Serial.println("5 Hz");
		break;
	}

	Serial.println("");
	delay(100);
}