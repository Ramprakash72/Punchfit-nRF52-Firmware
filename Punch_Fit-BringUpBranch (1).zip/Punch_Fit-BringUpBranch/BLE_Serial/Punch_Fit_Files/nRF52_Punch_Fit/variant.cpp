/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.
  Copyright (c) 2016 Sandeep Mistry All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "variant.h"

const uint32_t g_ADigitalPinMap[] = {
  // D0 - D7
  2, // LED3 refered as 0
  3, // LED2
  4, // LED1
  15, // Interrupt Pin for Sensor
  26, // J5 Pin2
  27, // J5 Pin3
  17, // Not used
  18, // Not used refered as 7

  // D8 - D13
  19, // Not used	refered as 8
  20, // Not used
  22, // Not used
  23, // Not used
  24, // Not used
  25, // J5 Pin1	refered as 13

  // A0 - A7
  14, // refered as 14
  16,
  28, // J4 Pin1
  29, // J4 Pin2
  30, // J4 Pin3
  31, // J4 Pin4
  5, // AIN3 (P0.05)
  13, // AIN0 (P0.02) / AREF	refered as 21

  // SDA, SCL
  11, // refered as 22
  12, // refered as 23

  // RX, TX
  8, // RX refered as 24
  6  // TX refered as 25
};
