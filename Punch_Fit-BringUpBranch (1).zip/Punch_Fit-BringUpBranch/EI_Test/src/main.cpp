/* Edge Impulse Arduino examples
 * Copyright (c) 2021 EdgeImpulse Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* Includes ---------------------------------------------------------------- */
#include <Arduino.h>
#include <PunchFit_inferencing.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <SPI.h>
#include <BLEPeripheral.h>
#include "BLESerial.h"

#define FREQUENCY_HZ EI_CLASSIFIER_FREQUENCY
#define INTERVAL_MS (1000 / (FREQUENCY_HZ + 1))

#define LED1 PIN_LED1
#define LED2 PIN_LED2
#define LED3 PIN_LED3

// define pins (varies per shield/board)
#define BLE_REQ 0
#define BLE_RDY 0
#define BLE_RST 0

#define MTU	20

BLESerial BLESerial(BLE_REQ, BLE_RDY, BLE_RST);

bool connection_status = false;

void connected(BLECentral &central)
{
	connection_status = true;
	Serial.println("Connected to ble");
}

void disconnected(BLECentral &central)
{
	connection_status = false;
	Serial.println("Disconnected from ble");
}


float features[EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE] = {
    // copy raw features here (for example from the 'Live classification' page)
    // see https://docs.edgeimpulse.com/docs/running-your-impulse-arduino
    // 1.6818, -1.2171, 5.9607, -1.4770, 0.2702, -4.3686, -0.8613, -3.3323, 8.7023, -0.9314, 0.1740, 0.1752, -0.6506, 1.1077, 10.3764, -0.2719, -1.3158, 4.9050, 3.6832, 6.4711, 10.9464, 0.2385, -1.7419, 0.9319, 2.8699, 1.5028, 8.8072, 0.7536, 0.0942, -4.1675, -2.8903, -5.9282, 7.4184, -0.5396, 0.7113, -2.4613, -2.8278, -2.8315, 8.7235, -1.7667, -0.7796, 1.5862, 3.0235, 5.2564, 10.1821, 0.1393, -1.2992, 2.8809, 3.6381, 5.8054, 9.9343, 1.4079, -0.2505, 0.0739, -1.6028, -0.3563, 7.9649, -0.9004, 0.4160, -4.2566, -2.0583, -2.6508, 6.7884, -1.9318, 0.2382, -1.7566, 2.1252, 1.4624, 8.2199, -0.5307, 0.0917, 4.1394, 2.3752, 5.1190, 10.9939, -0.7238, 0.6259, 0.9000, -0.6686, 3.4056, 12.5943, -0.3395, 1.3975, -3.9639
};

Adafruit_MPU6050 mpu;
static unsigned long last_interval_ms = 0;
size_t feature_ix = 0;

/**
 * @brief      Copy raw feature data in out_ptr
 *             Function called by inference library
 *
 * @param[in]  offset   The offset
 * @param[in]  length   The length
 * @param      out_ptr  The out pointer
 *
 * @return     0
 */
int raw_feature_get_data(size_t offset, size_t length, float *out_ptr)
{
	memcpy(out_ptr, features + offset, length * sizeof(float));
	return 0;
}

void SensorInit(mpu6050_accel_range_t Acceration_Range, mpu6050_bandwidth_t Bandwidth);

// forward received from Serial to BLESerial and vice versa
void forward()
{
	if (BLESerial && Serial)
	{
		int byte;
		while ((byte = BLESerial.read()) > 0)
			Serial.write((char)byte);
		while ((byte = Serial.read()) > 0)
			BLESerial.write((char)byte);
	}
}

void BLE_Printf(char *buf) 
{
	char temp_buf[21] = {0};
	for (int i = 0; i < strlen(buf); i += MTU) {
		strncpy(temp_buf, &buf[i], MTU);
		BLESerial.write(temp_buf);
		BLESerial.flush();
	}
}

/**
 * @brief      Arduino setup function
 */
void setup()
{
	// put your setup code here, to run once:
	Serial.begin(115200);

	BLESerial.setLocalName("UART");
	BLESerial.setEventHandler(BLEConnected, connected);
	BLESerial.setEventHandler(BLEDisconnected, disconnected);
	BLESerial.begin();

	SensorInit(MPU6050_RANGE_16_G, MPU6050_BAND_5_HZ);
	Serial.println("Edge Impulse Inferencing Demo");
	#if 0
	pinMode(PIN_LED1, OUTPUT);
	pinMode(PIN_LED2, OUTPUT);
	pinMode(PIN_LED3, OUTPUT);
	digitalWrite(PIN_LED1, LOW);
	digitalWrite(PIN_LED2, LOW);
	digitalWrite(PIN_LED3, LOW);
	#endif
}

/**
 * @brief      Arduino main function
 */
// void loop()
// {
// 	sensors_event_t a, g, temp;
//
// 	mpu.getEvent(&a, &g, &temp);
//
//
// 	ei_printf("Edge Impulse standalone inferencing (Arduino)\r\n");
//
// 	if (sizeof(features) / sizeof(float) != EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE)
// 	{
// 		ei_printf("The size of your 'features' array is not correct. Expected %lu items, but had %lu\r\n",
// 							EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE, sizeof(features) / sizeof(float));
// 		delay(1000);
// 		return;
// 	}
//
// 	ei_impulse_result_t result = {0};
//
// 	// the features are stored into flash, and we don't want to load everything into RAM
// 	signal_t features_signal;
// 	features_signal.total_length = sizeof(features) / sizeof(features[0]);
// 	features_signal.get_data = &raw_feature_get_data;
//
// 	// invoke the impulse
// 	EI_IMPULSE_ERROR res = run_classifier(&features_signal, &result, false /* debug */);
// 	ei_printf("run_classifier returned: %d\r\n", res);
//
// 	if (res != 0)
// 		return;
//
// 	// print the predictions
// 	ei_printf("Predictions ");
// 	ei_printf("(DSP: %d ms., Classification: %d ms., Anomaly: %d ms.)",
// 						result.timing.dsp, result.timing.classification, result.timing.anomaly);
// 	ei_printf(": \r\n");
// 	ei_printf("[");
// 	for (size_t ix = 0; ix < EI_CLASSIFIER_LABEL_COUNT; ix++)
// 	{
// 		ei_printf("%.5f", result.classification[ix].value);
// #if EI_CLASSIFIER_HAS_ANOMALY == 1
// 		ei_printf(", ");
// #else
// 		if (ix != EI_CLASSIFIER_LABEL_COUNT - 1)
// 		{
// 			ei_printf(", ");
// 		}
// #endif
// 	}
// #if EI_CLASSIFIER_HAS_ANOMALY == 1
// 	ei_printf("%.3f", result.anomaly);
// #endif
// 	ei_printf("]\r\n");
//
// 	// human-readable predictions
// 	for (size_t ix = 0; ix < EI_CLASSIFIER_LABEL_COUNT; ix++)
// 	{
// 		ei_printf("    %s: %.5f\r\n", result.classification[ix].label, result.classification[ix].value);
// 	}
// #if EI_CLASSIFIER_HAS_ANOMALY == 1
// 	ei_printf("    anomaly score: %.3f\n", result.anomaly);
// #endif
//
// 	delay(1000);
// }

void loop()
{
	sensors_event_t a, g, temp;
	char buf[200] = {0};
	char temp_buf[21] = {0};

	BLESerial.poll();

	if (millis() > last_interval_ms + INTERVAL_MS)
	{
		last_interval_ms = millis();

		// read sensor data in exactly the same way as in the Data Forwarder example
		mpu.getEvent(&a, &g, &temp);

		// fill the features buffer
		features[feature_ix++] = a.acceleration.x;
		features[feature_ix++] = a.acceleration.y;
		features[feature_ix++] = a.acceleration.z;
		features[feature_ix++] = g.gyro.roll;
		features[feature_ix++] = g.gyro.pitch;
		features[feature_ix++] = g.gyro.heading;

		// features buffer full? then classify!
		if (feature_ix == EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE)
		{
			ei_impulse_result_t result;

			// create signal from features frame
			signal_t signal;
			numpy::signal_from_buffer(features, EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE, &signal);

			// run classifier
			EI_IMPULSE_ERROR res = run_classifier(&signal, &result, false);
			ei_printf("run_classifier returned: %d\r\n", res);
			if (res != 0)
				return;

			// print predictions
			ei_printf("Predictions (DSP: %d ms., Classification: %d ms., Anomaly: %d ms.): \r\n",
				  result.timing.dsp, result.timing.classification, result.timing.anomaly);

			// print the predictions
			for (size_t ix = 0; ix < EI_CLASSIFIER_LABEL_COUNT; ix++)
			{
				ei_printf("%s:\t%.5f\r\n", result.classification[ix].label, result.classification[ix].value);
				sprintf(buf, "%s:\t%.5f\r\n",
					result.classification[ix].label, result.classification[ix].value);
				// BLE_Printf(buf);

				if (strstr(result.classification[ix].label, "Cross_Fast") &&
					result.classification[ix].value > 0.7) {
					Serial.println(result.classification[ix].label + String(" Detected"));
					sprintf(buf, "%s Detected", result.classification[ix].label);
					BLE_Printf(buf);
					#if 0
					digitalWrite(PIN_LED1, HIGH);
					delay(100);
					digitalWrite(PIN_LED1, LOW);
					#endif
				} else if (strstr(result.classification[ix].label, "Cross_Slow") &&
					result.classification[ix].value > 0.7) {
					Serial.println(result.classification[ix].label + String(" Detected"));
					sprintf(buf, "%s Detected", result.classification[ix].label);
					BLE_Printf(buf);
					#if 0
					digitalWrite(PIN_LED2, HIGH);
					delay(100);
					digitalWrite(PIN_LED2, LOW);
					#endif
				} else if (strstr(result.classification[ix].label, "Random") &&
					result.classification[ix].value > 0.7) {
					Serial.println(result.classification[ix].label + String(" Detected"));
					sprintf(buf, "%s Detected", result.classification[ix].label);
					BLE_Printf(buf);
					#if 0
					digitalWrite(PIN_LED3, HIGH);
					delay(100);
					digitalWrite(PIN_LED3, LOW);
					#endif
				} else if ((strstr(result.classification[ix].label, "Punch_Fast") || 
					strstr(result.classification[ix].label, "Punch_High")) &&
					result.classification[ix].value > 0.7) {
					Serial.println(result.classification[ix].label + String(" Detected"));
					sprintf(buf, "%s Detected", result.classification[ix].label);
					BLE_Printf(buf);
					#if 0
					digitalWrite(PIN_LED1, LOW);
					digitalWrite(PIN_LED2, LOW);
					digitalWrite(PIN_LED3, LOW);
					#endif
				} else if (strstr(result.classification[ix].label, "Punch_Medium") &&
					result.classification[ix].value > 0.7) {
					Serial.println(result.classification[ix].label + String(" Detected"));
					sprintf(buf, "%s Detected", result.classification[ix].label);
					BLE_Printf(buf);
					#if 0
					digitalWrite(PIN_LED1, LOW);
					digitalWrite(PIN_LED2, LOW);
					digitalWrite(PIN_LED3, LOW);
					#endif
				} else if (strstr(result.classification[ix].label, "Punch_Slow") &&
					result.classification[ix].value > 0.7) {
					Serial.println(result.classification[ix].label + String(" Detected"));
					sprintf(buf, "%s Detected", result.classification[ix].label);
					BLE_Printf(buf);
					#if 0
					digitalWrite(PIN_LED1, LOW);
					digitalWrite(PIN_LED2, LOW);
					digitalWrite(PIN_LED3, LOW);
					#endif
				}
			}
#if EI_CLASSIFIER_HAS_ANOMALY == 1
			ei_printf("anomaly:\t%.3f\n", result.anomaly);
#endif

			// reset features frame
			feature_ix = 0;
		}
	}
}

void SensorInit(mpu6050_accel_range_t Acceration_Range,
		mpu6050_bandwidth_t Bandwidth)
{
	if (!mpu.begin())
	{
		Serial.println("Failed to find MPU6050 chip");
		while (1)
		{
			delay(10);
		}
	}
#if defined(DEBUG_REQUIRED)
	Serial.println("MPU6050 Found!");
#endif

	// mpu.setAccelerometerRange(MPU6050_RANGE_16_G);
	mpu.setAccelerometerRange(Acceration_Range);
	Serial.print("Accelerometer range set to: ");
	switch (mpu.getAccelerometerRange())
	{
	case MPU6050_RANGE_2_G:
		Serial.println("+-2G");
		break;
	case MPU6050_RANGE_4_G:
		Serial.println("+-4G");
		break;
	case MPU6050_RANGE_8_G:
		Serial.println("+-8G");
		break;
	case MPU6050_RANGE_16_G:
		Serial.println("+-16G");
		break;
	}

	// mpu.setFilterBandwidth(MPU6050_BAND_5_HZ);
	mpu.setFilterBandwidth(Bandwidth);
	Serial.print("Filter bandwidth set to: ");
	switch (mpu.getFilterBandwidth())
	{
	case MPU6050_BAND_260_HZ:
		Serial.println("260 Hz");
		break;
	case MPU6050_BAND_184_HZ:
		Serial.println("184 Hz");
		break;
	case MPU6050_BAND_94_HZ:
		Serial.println("94 Hz");
		break;
	case MPU6050_BAND_44_HZ:
		Serial.println("44 Hz");
		break;
	case MPU6050_BAND_21_HZ:
		Serial.println("21 Hz");
		break;
	case MPU6050_BAND_10_HZ:
		Serial.println("10 Hz");
		break;
	case MPU6050_BAND_5_HZ:
		Serial.println("5 Hz");
		break;
	}

	Serial.println("");
	delay(100);
}