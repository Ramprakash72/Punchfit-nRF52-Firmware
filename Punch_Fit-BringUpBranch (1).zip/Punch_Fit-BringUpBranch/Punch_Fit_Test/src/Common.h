#ifndef __COMMON_H__
#define __COMMON_H__

#define NO_SENSOR		// If no sensor is used enable this
#define NEED_THRESHOLD		// If needed threshold to reduce data communication to application
#define APP_DEBUG_REQUIRED	// If serial debugging for application
// #define DEBUG_REQUIRED	// If sensor debugging is required enable this

#define INTERVAL_TO_SEND_DATA	1000U	// Interval for which the sensor needs to be read continuosly

#define NO_USER_DATA_PROFILE	// If no user data is provided/ mechanism to be implemented

#define MASS_FROM_WEIGHT(x) (x / 9.8)		// Calculates dynamic profile parameters

#if defined(NO_SENSOR)
#define FREQUENCY(x) (1 / x)
#define VELOCITY(x, y) (x * y)
#endif
#define MOMENTUM(x, y) (x * y)			// Calculates the Caloric data
#define KINETIC_ENERGY(x, y) (x * y / 2)


/*
 * Velocity charecteristic
 */
BLEPeripheral CaloricData = BLEPeripheral();
BLEService VelocityService = BLEService("ecb48f121bd041619dae9efab22f62a8");
BLEFloatCharacteristic VelocityCharacteristic = BLEFloatCharacteristic("1bd1", BLERead | BLENotify);
BLEDescriptor VelocityDescriptor = BLEDescriptor("2901", "Velocity m/s");

/*
 * Momentum charecteristic
 */
BLEService MomentumService = BLEService("7136237eacda4af79af4112a64dd4d3c");
BLEFloatCharacteristic MomentumCharacteristic = BLEFloatCharacteristic("acdb", BLERead | BLENotify);
BLEDescriptor MomentumDescriptor = BLEDescriptor("2901", "Momentum in kg*m/s");

/*
 * KE charecteristic
 */
BLEService KEService = BLEService("0b37c1dc602744b78707a06c6253a2a7");
BLEFloatCharacteristic KECharacteristic = BLEFloatCharacteristic("6028", BLERead | BLENotify);
BLEDescriptor KEDescriptor = BLEDescriptor("2901", "Kinetic Energy in Jouls");

/*
 * Profile Data charecteristic
 */
BLEService ProfileDataService = BLEService("de5e7561ff5542c58ea1e39fc951674e");
BLEFloatCharacteristic ProfileDataCharacteristic = BLEFloatCharacteristic("ff56", BLEWrite);
BLEDescriptor ProfileDataDescriptor = BLEDescriptor("2901", "Weight of arm in kgm/s");


uint32_t *device_id_address = (uint32_t*)&NRF_FICR->DEVICEADDR[0];
uint32_t device_id;
char DeviceName[30] = {0};

enum Gender_Classification
{
	MALE = 0,
	FEMALE,
};

struct User_Data
{
	float Mass_In_KG;
	float Arm_Length_In_Meter;
	int Age;
	float Arm_Weight_In_KG_Meter_Per_Second_Sqared;
	float Height_In_CM;
	bool Gender;
} Profile;

struct Calculation_Data
{
#if defined(NO_SENSOR)
	float Frequency;
#endif
	float Velocity;
	float Momentum;
	float Speed;
	float KE;
	float lastVelocityReading;
} Calculations;

bool LedState = LOW;

void SetupGpio(void);
#if defined(NO_USER_DATA_PROFILE)
void SetupProfileData(void);
#endif
void SetupBLEProfile(void);
void ReadDeviceID(void);
void PollOnData(void);

#endif