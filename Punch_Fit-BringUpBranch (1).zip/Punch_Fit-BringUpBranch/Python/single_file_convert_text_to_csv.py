# importing panda library
import pandas as pd
import os

# readinag given csv file
# and creating dataframe
os.chdir('D:\Git_Repos\PunchFit\Punch_Fit\Python\Punch_Data')
#for x in os.listdir():
#    if x.endswith(".txt"):
#        print(x)
#        file_obj = open(x, 'r+')
#        contents = file_obj.read()
#        file_obj.seek(0)
#        file_obj.truncate()
#        file_obj.write('timestamp,accX,accY,accZ,gyroX,gyroY,gyroZ\n')
#        file_obj.write(contents)
#        file_obj.close()
#        dataframe1 = pd.read_csv(x)
#        y = os.path.splitext(x)[0]
#        y = y + ".csv"
#        print(y)
#        dataframe1.to_csv(y)

dataframe1 = pd.read_csv("Random 21052011_0546.txt")
  
# storing this dataframe in a csv file
dataframe1.to_csv('Random 21052011_0546.csv',
                  index = None)
