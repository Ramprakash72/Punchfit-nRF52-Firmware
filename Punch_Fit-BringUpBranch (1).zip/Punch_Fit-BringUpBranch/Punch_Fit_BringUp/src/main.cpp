#include <Arduino.h>
#include <SPI.h>
#include <BLEPeripheral.h>
#include "MPU6050_Data.h"
#include "Common.h"

SensorData LatestData[3];
SensorData *BaseVal = &LatestData[0];
SensorData *MaxVal = &LatestData[1];
SensorData *Result = &LatestData[2];

volatile bool SendData = false;
uint32_t lastmillis;
uint32_t Reading_lastmillis;

void connected(BLECentral& central)
{
	Serial.println("Connected to ble");
}

void disconnected(BLECentral& central)
{
	Serial.println("Disconnected from ble");
}

void setup()
{
	Enable_DCDCRegulator();

#if defined(APP_DEBUG_REQUIRED) || defined(DEBUG_REQUIRED)
	Serial.begin(+9600);
#endif
	SetupGpio();

	Test_GPIO();

#if !defined(NO_SENSOR)
	SensorInit(MPU6050_RANGE_16_G, MPU6050_BAND_5_HZ);
#endif

#if defined(NO_USER_DATA_PROFILE)
	SetupProfileData();
#endif
	SetupBLEProfile();
	lastmillis = millis();
}

void setCharacteristicValues()
{
	#if defined(NO_SENSOR)
	float reading = random(100);
	if (reading == 0)
		reading = 1;
	Calculations.Frequency = FREQUENCY(reading);
	Calculations.Velocity = VELOCITY(Profile.Arm_Length_In_Meter, Calculation_Data.Frequency);
	#else
	Calculations.Velocity = Result->Velocity;
	#endif
	Calculations.Momentum = MOMENTUM(Calculations.Velocity, Profile.Arm_Weight_In_KG_Meter_Per_Second_Sqared);
	Calculations.KE = KINETIC_ENERGY(Calculations.Momentum, Calculations.Velocity);

	#if defined(NO_SENSOR)
	if (!isnan(reading) && significantChange(Calculations.lastVelocityReading, Calculations.Velocity, 0.05)) {
	#elif defined(NEED_THRESHOLD)
	if (significantChange(Calculations.lastVelocityReading, Calculations.Velocity, 0.5)) {
	#endif
		VelocityCharacteristic.setValueBE(Calculations.Velocity);
		MomentumCharacteristic.setValueBE(Calculations.Momentum);
		KECharacteristic.setValueBE(Calculations.KE);
#if defined(APP_DEBUG_REQUIRED)
		Serial.print(F("Velocity: "));
		Serial.print(Calculations.Velocity, 5);
		Serial.println(F(" m/s"));
		Serial.print(F("Momentum: "));
		Serial.print(Calculations.Momentum, 5);
		Serial.println(F(" Kg*m/s"));
		Serial.print(F("KE: "));
		Serial.print(Calculations.KE, 5);
		Serial.println(F(" Jouls"));
		Serial.println();
#endif
		Calculations.lastVelocityReading = Calculations.Velocity;
	#if defined(NO_SENSOR) || defined(NEED_THRESHOLD)
	}
	#endif
}

void blink_led()
{
	digitalWrite(LED_BUILTIN, HIGH);
	delay(100);
	digitalWrite(LED_BUILTIN, LOW);
	delay(100);
}

void loop()
{
	blink_led();
	BLECentral central = CaloricData.central();

	if (central) {
		if (central.connected()) {
			Profile.Arm_Weight_In_KG_Meter_Per_Second_Sqared = 
				ProfileDataCharacteristic.valueBE();
			#if defined(DEBUG_REQUIRED)
			Serial.println();
			Serial.print("Arm Weight :");
			Serial.print(Profile.Arm_Weight_In_KG_Meter_Per_Second_Sqared, 5);
			Serial.println();
			#endif
			MASS_FROM_WEIGHT(Profile.Arm_Weight_In_KG_Meter_Per_Second_Sqared);
		}
	}

	CaloricData.poll();
	if (millis() - lastmillis > INTERVAL_TO_SEND_DATA){
		SendData = true;
		lastmillis = millis();
	}

	if (SendData) {
		setCharacteristicValues();
		SendData = false;
	}

#if !defined(NO_SENSOR)
	PollOnData();
#endif
}

void Enable_DCDCRegulator()
{
	*DCDCEN_Address = 0x1;
}

void SetupGpio()
{
	pinMode(LED_BUILTIN, OUTPUT);
	// pinMode(PIN_BUTTON1, INPUT_PULLUP);
}

void Test_GPIO()
{
	for (int i = 0; i < 3; i++) {
		digitalWrite(LED_BUILTIN, HIGH);
		delay(100);
		digitalWrite(LED_BUILTIN, LOW);
		delay(100);
	}
}

#if defined(NO_USER_DATA_PROFILE)
void SetupProfileData()
{
	Profile.Age = 30;
	Profile.Arm_Length_In_Meter = 0.6;
	Profile.Gender = MALE;
	Profile.Height_In_CM = 168;
	Profile.Arm_Weight_In_KG_Meter_Per_Second_Sqared = 11;
	Profile.Mass_In_KG = MASS_FROM_WEIGHT(Profile.Arm_Weight_In_KG_Meter_Per_Second_Sqared);
}
#endif

void SetupBLEProfile()
{
	ReadDeviceID();
	sprintf(DeviceName, "Punch Fit %x", device_id);

	CaloricData.setLocalName(DeviceName);
	CaloricData.setAdvertisedServiceUuid(VelocityService.uuid());
	CaloricData.addAttribute(VelocityService);
	CaloricData.addAttribute(VelocityCharacteristic);
	CaloricData.addAttribute(VelocityDescriptor);

	CaloricData.setAdvertisedServiceUuid(MomentumService.uuid());
	CaloricData.addAttribute(MomentumService);
	CaloricData.addAttribute(MomentumCharacteristic);
	CaloricData.addAttribute(MomentumDescriptor);

	CaloricData.setAdvertisedServiceUuid(KEService.uuid());
	CaloricData.addAttribute(KEService);
	CaloricData.addAttribute(KECharacteristic);
	CaloricData.addAttribute(KEDescriptor);

	CaloricData.setAdvertisedServiceUuid(ProfileDataService.uuid());
	CaloricData.addAttribute(ProfileDataService);
	CaloricData.addAttribute(ProfileDataCharacteristic);
	CaloricData.addAttribute(ProfileDataDescriptor);


	// VelocityCharacteristic.setEventHandler(BLESubscribed, notify_now);
	CaloricData.setEventHandler(BLEConnected, connected);
	CaloricData.setEventHandler(BLEDisconnected, disconnected);
	CaloricData.begin();
}

void ReadDeviceID()
{
	memcpy(&device_id, device_id_address, sizeof(uint32_t));

#if defined(DEBUG_REQUIRED)
	Serial.print("Device Address[0]: ");
	Serial.print(device_id, HEX);
	Serial.println();
#endif
}

void PollOnData()
{
	*BaseVal = GetSensorData();
	Reading_lastmillis = BaseVal->time;
	do {
		GetSensorData();
	} while (millis() - Reading_lastmillis < INTERVAL_TO_SEND_DATA);
	
	*MaxVal = FindMax();
	*Result = GetVelocity(BaseVal, MaxVal);

#if defined(DEBUG_REQUIRED)
	Serial.print("Velocity Received: ");
	Serial.print(Result->Velocity);
	Serial.println("m/s");
	Serial.println();
#endif
}
