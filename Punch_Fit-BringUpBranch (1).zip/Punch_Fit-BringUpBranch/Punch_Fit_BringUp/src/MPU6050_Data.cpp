#include "MPU6050_Data.h"

#define MAX_VAL_TO_CALIBRATE 		5
#define MAX_VAL_IN_SEC			25
#define CONVERT_TO_METER_PER_SEC	1000

Adafruit_MPU6050 mpu;
float vectorprevious;
float vector;
float calibrated_base = 0;
float vector_array[MAX_VAL_TO_CALIBRATE];

SensorData G_Data[MAX_VAL_IN_SEC] = {0};
int ReadPos;

static void FindBase()
{
	sensors_event_t a, g, temp;
	mpu.getEvent(&a, &g, &temp);
	calibrated_base = 0;
	for (int i = 0; i < MAX_VAL_TO_CALIBRATE; i++)
	{
		vector_array[i] = sqrt((a.acceleration.x * a.acceleration.x) +
				(a.acceleration.y * a.acceleration.y) +
				(a.acceleration.z * a.acceleration.z));
		calibrated_base += vector_array[i];
	}
	calibrated_base /= MAX_VAL_TO_CALIBRATE;
	vectorprevious = calibrated_base;
	vector = 0;
}

static void CleanUpData()
{
	memset(G_Data, 0x00, sizeof(G_Data));
	ReadPos = 0;
}

void SensorInit(mpu6050_accel_range_t Acceration_Range, 
	mpu6050_bandwidth_t Bandwidth)
{
	if (!mpu.begin())
	{
		Serial.println("Failed to find MPU6050 chip");
		while (1)
		{
			delay(10);
		}
	}
#if defined(DEBUG_REQUIRED)
	Serial.println("MPU6050 Found!");
#endif

	// mpu.setAccelerometerRange(MPU6050_RANGE_16_G);
	mpu.setAccelerometerRange(Acceration_Range);
	Serial.print("Accelerometer range set to: ");
	switch (mpu.getAccelerometerRange())
	{
	case MPU6050_RANGE_2_G:
		Serial.println("+-2G");
		break;
	case MPU6050_RANGE_4_G:
		Serial.println("+-4G");
		break;
	case MPU6050_RANGE_8_G:
		Serial.println("+-8G");
		break;
	case MPU6050_RANGE_16_G:
		Serial.println("+-16G");
		break;
	}

	// mpu.setFilterBandwidth(MPU6050_BAND_5_HZ);
	mpu.setFilterBandwidth(Bandwidth);
	Serial.print("Filter bandwidth set to: ");
	switch (mpu.getFilterBandwidth())
	{
	case MPU6050_BAND_260_HZ:
		Serial.println("260 Hz");
		break;
	case MPU6050_BAND_184_HZ:
		Serial.println("184 Hz");
		break;
	case MPU6050_BAND_94_HZ:
		Serial.println("94 Hz");
		break;
	case MPU6050_BAND_44_HZ:
		Serial.println("44 Hz");
		break;
	case MPU6050_BAND_21_HZ:
		Serial.println("21 Hz");
		break;
	case MPU6050_BAND_10_HZ:
		Serial.println("10 Hz");
		break;
	case MPU6050_BAND_5_HZ:
		Serial.println("5 Hz");
		break;
	}

	Serial.println("");
	delay(100);

	FindBase();
}

SensorData GetSensorData()
{
	sensors_event_t a, g, temp;
	mpu.getEvent(&a, &g, &temp);

	vector = sqrt((a.acceleration.x * a.acceleration.x) +
			(a.acceleration.y * a.acceleration.y) +
			(a.acceleration.z * a.acceleration.z));

	G_Data[ReadPos].Vector = vector;
	G_Data[ReadPos].time = millis();

#if defined(DEBUG_REQUIRED)
	Serial.print("Value no: ");
	Serial.println(ReadPos);
	Serial.print("Vector: ");
	Serial.println(G_Data[ReadPos].Vector);
	Serial.print("Time: ");
	Serial.println(G_Data[ReadPos].time);
	Serial.println();
#endif
	if (ReadPos > MAX_VAL_IN_SEC)
		ReadPos = 0;

	return G_Data[ReadPos++];
}

SensorData FindMax()
{
	float max = G_Data[0].Vector;
	SensorData Max_Object = {0};
	int i;

	for (i = 0; i < MAX_VAL_IN_SEC; i++) {
		if (max < G_Data[i].Vector) {
			Max_Object = G_Data[i];
		}
	}

	return Max_Object;
}

SensorData GetVelocity(SensorData *base, SensorData *Max)
{
	SensorData Result = {0};

	Result.Velocity = abs((Max->Vector - base->Vector) / (Max->time - base->time));
	Result.Velocity *= CONVERT_TO_METER_PER_SEC;
#if defined(DEBUG_REQUIRED)
	Serial.print("Max Vector: ");
	Serial.println(Max->Vector);
	Serial.print("Max time: ");
	Serial.println(Max->time);
	Serial.print("Base Vector: ");
	Serial.println(base->Vector);
	Serial.print("Base Time: ");
	Serial.println(base->time);
	Serial.print("Velocity: ");
	Serial.println(Result.Velocity);
	Serial.println();
#endif
	FindBase();
	CleanUpData();
	return Result;
}

boolean significantChange(float val1, float val2, float threshold)
{
	return (abs(val1 - val2) >= threshold);
}