#ifndef __MPU6050_DATA_H__
#define __MPU6050_DATA_H__

#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

/*
 * SensorData structure holds G vector and later computes velocity
 */
typedef struct{
	float Velocity;
	float Vector;
	uint32_t time;
}SensorData;

void SensorInit(mpu6050_accel_range_t Acceration_Range, mpu6050_bandwidth_t Bandwidth);
SensorData GetVelocity(SensorData *base, SensorData *Max);
boolean significantChange(float val1, float val2, float threshold);
SensorData GetSensorData(void);
SensorData FindMax(void);

#endif